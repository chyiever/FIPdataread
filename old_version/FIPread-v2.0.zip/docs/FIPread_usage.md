# FIPread Usage

## Dependencies

Install the required packages before running:

```powershell
pip install numpy scipy PyQt5 pyqtgraph nptdms
```

## Run

From the project root:

```powershell
python .\scripts\fipread_app.py
```

## Basic Workflow

1. Select a directory that contains `.npz` or `.tdms` files.
2. Choose sort field and sort order.
3. Select a file from the file list.
4. View the time-domain waveform in the upper plot.
5. Enable or disable filtering for display.
6. Use `Zoom` mode for rectangle zoom.
7. Use `Window PSD` mode to drag a short-time window.
8. View the PSD result in the lower plot.

## Notes

- Time-domain X-axis is derived from the file name timestamp.
- `.tdms` files require `nptdms`; the waveform start time and sample rate are parsed from the file name.
- PSD always uses raw unfiltered data.
- If `data_info` fails to deserialize, the application still opens the file and shows a warning in the status bar.
