# FIPread 开发日志

## 1. 项目概述

FIPread 是一个基于 `Python 3.9+`、`PyQt5` 和 `pyqtgraph` 开发的桌面数据读取与分析软件，用于加载、浏览、显示和分析 `.npz` 格式的 FIP 相位数据。

软件目标：

- 面向大数据量时域波形提供快速浏览能力
- 支持短时窗口选取与 PSD 分析
- 提供常用显示滤波能力
- 保持界面交互清晰、稳定、可维护

---

## 2. 当前版本功能

### 2.1 文件浏览

- 选择目录后，自动扫描当前目录下所有 `.npz` 文件
- 不递归子目录
- 文件列表支持：
  - 首页
  - 上 30 个
  - 下 30 个
  - 尾页
  - 当前页号 / 总数显示
  - 按文件名排序
  - 按修改时间排序
  - 升序 / 降序切换

### 2.2 数据读取

- 按示例 `.npz` 文件实际结构读取
- 支持主字段：
  - `phase_data`
  - `sample_rate`
  - `comm_count`
  - `timestamp`
  - `data_info`
- 如果 `data_info` 因 NumPy/Pickle 兼容问题反序列化失败，软件允许降级打开，不影响主流程

### 2.3 时域图显示

- 显示相位时域波形
- 横轴采用从文件名解析得到的绝对时间
- 纵轴单位为 `rad`
- 时域曲线当前为红色
- 支持自动 Y 轴
- 支持手动设置 Y 轴上下限

### 2.4 滤波显示

时域显示支持以下滤波方式：

- Band-pass
- High-pass
- Low-pass

当前默认配置：

- 默认启用滤波
- 默认模式为 `30000 Hz` 高通

说明：

- 滤波仅作用于时域显示
- PSD 始终使用原始未滤波数据计算

### 2.5 时域交互

软件提供两种交互模式：

- `Zoom Mode`
- `Window PSD Mode`

支持的操作：

- 矩形放大
- `Shift + 左键拖动` 或中键拖动实现波形左右平移
- `Zoom Out 2x`
- `Reset View`
- `Back View` 返回上一步缩放/平移视图

### 2.6 PSD 分析

- 时域图下方固定显示 PSD 图
- 通过 `Window PSD Mode` 拖拽短时窗口后自动计算 PSD
- 支持左右方向拖拽
- 仅保留一个短时窗口
- 右键清除当前短时窗口
- 短时窗口在时域图中使用黄色阴影标示

当前 PSD 设置：

- 计算方法：Welch
- `window = hann`
- `detrend = linear`
- `nperseg = 选窗全长`
- `noverlap = 50%`
- `scaling = density`
- 横轴：对数坐标
- 默认显示频率范围：`1000 Hz ~ fs/2`
- 纵轴固定范围：`-120 dB ~ -45 dB`
- 标签：`PSD (dB rad^2/Hz)`

### 2.7 长度显示

时域图和 PSD 图中间的控制区当前还会显示：

- `Visible: ... s` 当前时域图 x 轴可见时长
- `Window: ... s` 当前短时窗口时长

---

## 3. 面向用户的使用说明

### 3.1 启动方式

在项目根目录执行：

```powershell
python .\scripts\fipread_app.py
```

### 3.2 基本使用流程

1. 启动软件
2. 在左侧选择数据目录
3. 通过文件列表选择一个 `.npz` 文件
4. 在右侧查看时域图
5. 如有需要，调整滤波模式和滤波参数
6. 如有需要，调整 Y 轴显示范围
7. 点击时域图下方按钮切换交互模式
8. 在 `Window PSD Mode` 下拖拽短时窗口
9. 在下方查看 PSD

### 3.3 常用按钮说明

- `Zoom Mode`：矩形缩放模式
- `Window PSD Mode`：短时窗口选择模式
- `Back View`：返回上一步缩放/平移视图
- `Zoom Out 2x`：缩小当前视图
- `Reset View`：恢复当前文件初始视图

### 3.4 滤波说明

- `Band-pass`：设置低截止和高截止频率
- `High-pass`：主要使用低截止频率
- `Low-pass`：主要使用高截止频率

注意：

- 滤波仅影响时域图显示
- PSD 计算始终使用原始数据

### 3.5 已知用户侧说明

- 如果某些文件的 `data_info` 读取失败，状态栏会提示，但不影响主波形与 PSD 分析
- 对数 PSD 横轴不会显示 `0 Hz`
- 大文件首次打开速度与文件压缩程度、磁盘速度有关

---

## 4. 面向开发者的实现说明

### 4.1 代码目录

当前主要代码位于：

- [fipread_app.py](/E:/codes/FIPread/scripts/fipread_app.py)
- [main_window.py](/E:/codes/FIPread/scripts/fipread/main_window.py)
- [data_access.py](/E:/codes/FIPread/scripts/fipread/data_access.py)
- [processing.py](/E:/codes/FIPread/scripts/fipread/processing.py)
- [plotting.py](/E:/codes/FIPread/scripts/fipread/plotting.py)
- [models.py](/E:/codes/FIPread/scripts/fipread/models.py)

### 4.2 模块职责

`fipread_app.py`

- 程序入口
- 创建 Qt 应用并启动主窗口

`main_window.py`

- 主界面
- 控件布局
- 文件列表逻辑
- 时域图与 PSD 图联动
- 交互模式管理
- 视图历史管理

`data_access.py`

- 目录扫描
- 文件排序与分页
- `.npz` 读取
- 文件名时间解析
- `data_info` 降级读取

`processing.py`

- 滤波参数校验
- 时域显示滤波
- Welch PSD 计算

`plotting.py`

- 自定义绝对时间轴
- pyqtgraph 绘图样式配置

`models.py`

- 枚举定义
- 数据模型定义

### 4.3 关键设计点

#### 4.3.1 大数据绘图

时域图主绘制采用 `pyqtgraph`，并启用：

- `setClipToView(True)`
- `setDownsampling(auto=True, method="peak")`
- `setSkipFiniteCheck(True)`

设计目的：

- 提高大数组绘制性能
- 缩小缩放和平移时的重绘压力

#### 4.3.2 时间轴处理

时域图横轴底层仍使用样本点索引。

显示层通过 `AbsoluteTimeAxis` 将“样本索引 / 采样率”转换为绝对时间字符串，避免额外构造超大时间数组。

#### 4.3.3 PSD 对数横轴

PSD 图使用对数横轴显示，注意点：

- 必须过滤 `0 Hz`
- 设置显示范围时要传入 `log10(freq)` 对应范围，而不是线性 Hz 数值

否则会出现异常坐标范围。

#### 4.3.4 `data_info` 兼容问题

示例数据中的 `data_info` 可能是 pickle 对象，且与当前 NumPy 环境不兼容，典型错误为：

```text
ModuleNotFoundError: No module named 'numpy._core'
```

当前处理策略：

- 主字段正常读取
- `data_info` 单独 try/except
- 失败时仅记录 warning，不中断文件打开

#### 4.3.5 视图历史

时域图当前维护视图状态历史，用于支持：

- 缩放回退
- 平移回退

实现要点：

- 监听 `ViewBox.sigRangeChanged`
- 记录 `xRange` 和 `yRange`
- 避免初始化默认视图污染历史

---

## 5. 当前默认配置

- 默认滤波启用
- 默认滤波模式：`High-pass`
- 默认高通截止频率：`30000 Hz`
- 时域曲线颜色：红色
- 网格：黑色
- 坐标轴：黑色
- 刻度文字：黑色
- PSD 横轴：对数
- PSD 纵轴固定：`-120 dB ~ -45 dB`

---

## 6. 开发过程中已处理的问题

### 6.1 `data_info` 反序列化失败

问题：

- 示例文件中的 `data_info` 无法在当前环境稳定反序列化

处理：

- 将其改为非阻塞读取
- 不影响主流程

### 6.2 PSD 对数轴异常

问题：

- 对数横轴下错误使用线性范围设置，会出现 `10^273` 一类异常范围

处理：

- 过滤 `0 Hz`
- 使用 `log10(lower_hz)` 和 `log10(upper_hz)` 设置范围

### 6.3 交互冲突

问题：

- 矩形缩放、短时窗口选取、平移操作之间容易冲突

处理：

- 使用模式按钮切换 `Zoom` 和 `Window PSD`
- 平移改为 `Shift + 左键` 或中键拖动

### 6.4 视图回退

问题：

- 普通缩放恢复只能回到初始状态，不能逐步回退

处理：

- 增加 `Back View`
- 记录视图历史状态

---

## 7. 后续可扩展方向

- 根据滤波模式动态启用/禁用频率输入框
- 增加后台线程读取，进一步优化大文件加载体验
- 增加错误文件明细弹窗，而不仅仅是状态栏提示
- 增加导出截图、导出 PSD 数据功能
- 增加打包脚本，输出独立可执行版本
- 增加单元测试和集成测试

---

## 8. 结论

当前版本已经具备：

- 数据目录浏览
- 大数据时域显示
- 显示滤波
- 短时窗口 PSD 分析
- 视图回退与平移
- 用户侧基础操作闭环

对于用户，当前版本已经可以完成日常浏览和分析任务。  
对于开发者，当前项目结构已经具备继续扩展和维护的基础。
