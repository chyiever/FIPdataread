from __future__ import annotations

from typing import Optional

import numpy as np
from scipy.signal import butter, sosfiltfilt, welch

from .models import FilterMode


def validate_filter(
    enabled: bool,
    mode: FilterMode,
    sample_rate: float,
    low_cut_hz: float,
    high_cut_hz: float,
) -> tuple[bool, Optional[str]]:
    if not enabled:
        return True, None

    nyquist = sample_rate / 2.0
    if mode == FilterMode.BANDPASS:
        if low_cut_hz <= 0 or high_cut_hz <= 0:
            return False, "Band-pass cutoff values must be > 0."
        if low_cut_hz >= high_cut_hz:
            return False, "Band-pass low cutoff must be lower than high cutoff."
        if high_cut_hz >= nyquist:
            return False, f"High cutoff must be lower than Nyquist ({nyquist:.1f} Hz)."
    elif mode == FilterMode.HIGHPASS:
        if low_cut_hz <= 0:
            return False, "High-pass cutoff must be > 0."
        if low_cut_hz >= nyquist:
            return False, f"High-pass cutoff must be lower than Nyquist ({nyquist:.1f} Hz)."
    elif mode == FilterMode.LOWPASS:
        if high_cut_hz <= 0:
            return False, "Low-pass cutoff must be > 0."
        if high_cut_hz >= nyquist:
            return False, f"Low-pass cutoff must be lower than Nyquist ({nyquist:.1f} Hz)."
    return True, None


def apply_display_filter(
    values: np.ndarray,
    sample_rate: float,
    enabled: bool,
    mode: FilterMode,
    low_cut_hz: float,
    high_cut_hz: float,
) -> np.ndarray:
    result = np.asarray(values, dtype=np.float64)
    if result.size == 0 or not enabled:
        return result

    nyquist = sample_rate / 2.0
    if mode == FilterMode.BANDPASS:
        sos = butter(
            N=4,
            Wn=[low_cut_hz / nyquist, high_cut_hz / nyquist],
            btype="bandpass",
            output="sos",
        )
    elif mode == FilterMode.HIGHPASS:
        sos = butter(
            N=4,
            Wn=low_cut_hz / nyquist,
            btype="highpass",
            output="sos",
        )
    else:
        sos = butter(
            N=4,
            Wn=high_cut_hz / nyquist,
            btype="lowpass",
            output="sos",
        )

    return sosfiltfilt(sos, result)


def compute_window_psd(values: np.ndarray, sample_rate: float) -> tuple[np.ndarray, np.ndarray]:
    signal = np.asarray(values, dtype=np.float64)
    if signal.size < 2:
        return np.array([], dtype=np.float64), np.array([], dtype=np.float64)

    nperseg = signal.size
    noverlap = nperseg // 2
    freqs, psd = welch(
        signal,
        fs=sample_rate,
        window="hann",
        nperseg=nperseg,
        noverlap=noverlap,
        detrend="linear",
        scaling="density",
        return_onesided=True,
    )
    floor = np.finfo(np.float64).tiny
    psd_db = 10.0 * np.log10(np.maximum(psd, floor))
    return freqs, psd_db
