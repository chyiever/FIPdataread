"""FIPread application package."""

