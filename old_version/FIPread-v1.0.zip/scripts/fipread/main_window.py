from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
import pyqtgraph as pg
from PyQt5 import QtCore, QtGui, QtWidgets

from .data_access import list_npz_files, load_waveform, paginate_files
from .models import (
    PAGE_SIZE,
    FileRecord,
    FilterMode,
    InteractionMode,
    LoadedWaveform,
    SortField,
)
from .plotting import AbsoluteTimeAxis, configure_plot_widget, make_pen
from .processing import apply_display_filter, compute_window_psd, validate_filter


class TimePlotWidget(pg.PlotWidget):
    windowSelected = QtCore.pyqtSignal(int, int)
    clearSelectionRequested = QtCore.pyqtSignal()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._interaction_mode = InteractionMode.ZOOM
        self._selection_active = False
        self._selection_start_x = 0.0
        self._selection_region: Optional[pg.LinearRegionItem] = None
        self._data_length = 0
        self._sample_rate = 1.0
        self._min_window_samples = 1
        self._pan_active = False
        self._pan_last_scene_pos: Optional[QtCore.QPointF] = None

    def set_interaction_mode(self, mode: InteractionMode) -> None:
        self._interaction_mode = mode
        self.getViewBox().setMouseMode(
            pg.ViewBox.RectMode if mode == InteractionMode.ZOOM else pg.ViewBox.PanMode
        )

    def set_data_context(self, data_length: int, sample_rate: float, min_window_seconds: float) -> None:
        self._data_length = max(0, int(data_length))
        self._sample_rate = max(float(sample_rate), 1.0)
        self._min_window_samples = max(1, int(round(min_window_seconds * self._sample_rate)))

    def set_selection_region(self, start_index: int, end_index: int) -> None:
        lo, hi = sorted((start_index, end_index))
        if self._selection_region is None:
            self._selection_region = pg.LinearRegionItem(
                values=(lo, hi),
                brush=(255, 215, 0, 60),
                pen=make_pen("#CC9900", 1),
                movable=False,
            )
            self.addItem(self._selection_region)
        else:
            self._selection_region.setRegion((lo, hi))

    def clear_selection_region(self) -> None:
        if self._selection_region is not None:
            self.removeItem(self._selection_region)
            self._selection_region = None

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MiddleButton or (
            event.button() == QtCore.Qt.LeftButton
            and bool(event.modifiers() & QtCore.Qt.ShiftModifier)
        ):
            self._pan_active = True
            self._pan_last_scene_pos = self.mapToScene(event.pos())
            event.accept()
            return

        if self._interaction_mode == InteractionMode.WINDOW_PSD:
            if event.button() == QtCore.Qt.RightButton:
                self.clearSelectionRequested.emit()
                event.accept()
                return
            if event.button() == QtCore.Qt.LeftButton:
                point = self.plotItem.vb.mapSceneToView(self.mapToScene(event.pos()))
                self._selection_start_x = point.x()
                self._selection_active = True
                bounded = self._clamp_x(self._selection_start_x)
                self.set_selection_region(int(round(bounded)), int(round(bounded)))
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._pan_active and self._pan_last_scene_pos is not None:
            current_scene_pos = self.mapToScene(event.pos())
            previous_view = self.plotItem.vb.mapSceneToView(self._pan_last_scene_pos)
            current_view = self.plotItem.vb.mapSceneToView(current_scene_pos)
            delta_x = previous_view.x() - current_view.x()
            if delta_x != 0.0:
                self.plotItem.vb.translateBy(x=delta_x, y=0.0)
            self._pan_last_scene_pos = current_scene_pos
            event.accept()
            return

        if self._interaction_mode == InteractionMode.WINDOW_PSD and self._selection_active:
            point = self.plotItem.vb.mapSceneToView(self.mapToScene(event.pos()))
            current_x = self._clamp_x(point.x())
            start_x = self._clamp_x(self._selection_start_x)
            self.set_selection_region(int(round(start_x)), int(round(current_x)))
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._pan_active and (
            event.button() == QtCore.Qt.MiddleButton or event.button() == QtCore.Qt.LeftButton
        ):
            self._pan_active = False
            self._pan_last_scene_pos = None
            event.accept()
            return

        if (
            self._interaction_mode == InteractionMode.WINDOW_PSD
            and self._selection_active
            and event.button() == QtCore.Qt.LeftButton
        ):
            self._selection_active = False
            point = self.plotItem.vb.mapSceneToView(self.mapToScene(event.pos()))
            start_x = int(round(self._clamp_x(self._selection_start_x)))
            end_x = int(round(self._clamp_x(point.x())))
            lo, hi = sorted((start_x, end_x))
            if hi - lo < self._min_window_samples:
                hi = min(self._data_length - 1, lo + self._min_window_samples)
            if hi > lo:
                self.set_selection_region(lo, hi)
                self.windowSelected.emit(lo, hi)
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def _clamp_x(self, value: float) -> float:
        if self._data_length <= 1:
            return 0.0
        return min(max(float(value), 0.0), float(self._data_length - 1))


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("FIPread")
        self.resize(1500, 920)

        self._all_files: list[FileRecord] = []
        self._page_index = 0
        self._current_waveform: Optional[LoadedWaveform] = None
        self._current_display_values = np.array([], dtype=np.float64)
        self._view_history: list[tuple[tuple[float, float], tuple[float, float]]] = []
        self._last_view_state: Optional[tuple[tuple[float, float], tuple[float, float]]] = None
        self._suspend_history = False

        self._build_ui()
        self._bind_events()
        self._refresh_file_list()

    def _build_ui(self) -> None:
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)

        main_layout = QtWidgets.QHBoxLayout(central)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(8)

        control_panel = QtWidgets.QFrame()
        control_panel.setMinimumWidth(560)
        control_layout = QtWidgets.QVBoxLayout(control_panel)

        directory_group = QtWidgets.QGroupBox("Directory")
        directory_layout = QtWidgets.QGridLayout(directory_group)
        self.directory_edit = QtWidgets.QLineEdit(str(Path.cwd() / "data"))
        self.browse_button = QtWidgets.QPushButton("Browse")
        self.refresh_button = QtWidgets.QPushButton("Refresh")
        directory_layout.addWidget(self.directory_edit, 0, 0, 1, 2)
        directory_layout.addWidget(self.browse_button, 0, 2)
        directory_layout.addWidget(self.refresh_button, 1, 2)

        sort_group = QtWidgets.QGroupBox("File List")
        sort_layout = QtWidgets.QGridLayout(sort_group)
        self.sort_field_combo = QtWidgets.QComboBox()
        self.sort_field_combo.addItem("Name", SortField.NAME)
        self.sort_field_combo.addItem("Modified Time", SortField.MTIME)
        self.sort_order_combo = QtWidgets.QComboBox()
        self.sort_order_combo.addItem("Ascending", True)
        self.sort_order_combo.addItem("Descending", False)
        self.file_list = QtWidgets.QListWidget()
        self.file_list.setMinimumSize(520, 560)
        self.page_info_label = QtWidgets.QLabel("Page 0 / 0 | Total 0")
        self.home_button = QtWidgets.QPushButton("Home")
        self.prev_button = QtWidgets.QPushButton("Previous 30")
        self.next_button = QtWidgets.QPushButton("Next 30")
        self.end_button = QtWidgets.QPushButton("End")
        sort_layout.addWidget(QtWidgets.QLabel("Sort By"), 0, 0)
        sort_layout.addWidget(self.sort_field_combo, 0, 1)
        sort_layout.addWidget(QtWidgets.QLabel("Order"), 1, 0)
        sort_layout.addWidget(self.sort_order_combo, 1, 1)
        sort_layout.addWidget(self.file_list, 2, 0, 1, 3)
        sort_layout.addWidget(self.page_info_label, 3, 0, 1, 3)
        sort_layout.addWidget(self.home_button, 4, 0)
        sort_layout.addWidget(self.prev_button, 4, 1)
        sort_layout.addWidget(self.next_button, 5, 0)
        sort_layout.addWidget(self.end_button, 5, 1)

        filter_group = QtWidgets.QGroupBox("Display Controls")
        filter_layout = QtWidgets.QGridLayout(filter_group)
        self.filter_enabled_checkbox = QtWidgets.QCheckBox("Enable Filter")
        self.filter_enabled_checkbox.setChecked(True)
        self.filter_mode_combo = QtWidgets.QComboBox()
        self.filter_mode_combo.addItem(FilterMode.BANDPASS.value, FilterMode.BANDPASS)
        self.filter_mode_combo.addItem(FilterMode.HIGHPASS.value, FilterMode.HIGHPASS)
        self.filter_mode_combo.addItem(FilterMode.LOWPASS.value, FilterMode.LOWPASS)
        self.low_cut_spin = QtWidgets.QDoubleSpinBox()
        self.low_cut_spin.setDecimals(3)
        self.low_cut_spin.setMaximum(1e9)
        self.low_cut_spin.setValue(30000.0)
        self.high_cut_spin = QtWidgets.QDoubleSpinBox()
        self.high_cut_spin.setDecimals(3)
        self.high_cut_spin.setMaximum(1e9)
        self.high_cut_spin.setValue(50000.0)
        self.filter_mode_combo.setCurrentIndex(1)
        self.apply_filter_button = QtWidgets.QPushButton("Apply Display Filter")
        self.y_min_spin = QtWidgets.QDoubleSpinBox()
        self.y_min_spin.setDecimals(6)
        self.y_min_spin.setRange(-1e12, 1e12)
        self.y_min_spin.setValue(0.0)
        self.y_max_spin = QtWidgets.QDoubleSpinBox()
        self.y_max_spin.setDecimals(6)
        self.y_max_spin.setRange(-1e12, 1e12)
        self.y_max_spin.setValue(0.0)
        self.apply_y_range_button = QtWidgets.QPushButton("Apply Y Range")
        filter_layout.addWidget(self.filter_enabled_checkbox, 0, 0, 1, 2)
        filter_layout.addWidget(QtWidgets.QLabel("Filter Mode"), 1, 0)
        filter_layout.addWidget(self.filter_mode_combo, 1, 1)
        filter_layout.addWidget(QtWidgets.QLabel("Low Cut (Hz)"), 2, 0)
        filter_layout.addWidget(self.low_cut_spin, 2, 1)
        filter_layout.addWidget(QtWidgets.QLabel("High Cut (Hz)"), 3, 0)
        filter_layout.addWidget(self.high_cut_spin, 3, 1)
        filter_layout.addWidget(self.apply_filter_button, 4, 0, 1, 2)
        filter_layout.addWidget(QtWidgets.QLabel("Y Min"), 5, 0)
        filter_layout.addWidget(self.y_min_spin, 5, 1)
        filter_layout.addWidget(QtWidgets.QLabel("Y Max"), 6, 0)
        filter_layout.addWidget(self.y_max_spin, 6, 1)
        filter_layout.addWidget(self.apply_y_range_button, 7, 0, 1, 2)

        control_layout.addWidget(directory_group)
        control_layout.addWidget(sort_group, stretch=1)
        control_layout.addWidget(filter_group)
        control_layout.addStretch(1)

        right_panel = QtWidgets.QSplitter(QtCore.Qt.Vertical)
        axis = AbsoluteTimeAxis("bottom")
        self.time_plot = TimePlotWidget(axisItems={"bottom": axis})
        time_panel = QtWidgets.QWidget()
        time_layout = QtWidgets.QVBoxLayout(time_panel)
        time_layout.setContentsMargins(0, 0, 0, 0)
        time_layout.setSpacing(6)
        self.zoom_mode_button = QtWidgets.QPushButton("Zoom Mode")
        self.zoom_mode_button.setCheckable(True)
        self.zoom_mode_button.setChecked(True)
        self.psd_mode_button = QtWidgets.QPushButton("Window PSD Mode")
        self.psd_mode_button.setCheckable(True)
        self.back_view_button = QtWidgets.QPushButton("Back View")
        self.back_view_button.setEnabled(False)
        self.reset_view_button = QtWidgets.QPushButton("Reset View")
        self.zoom_out_button = QtWidgets.QPushButton("Zoom Out 2x")
        self.mode_button_group = QtWidgets.QButtonGroup(self)
        self.mode_button_group.setExclusive(True)
        self.mode_button_group.addButton(self.zoom_mode_button)
        self.mode_button_group.addButton(self.psd_mode_button)
        button_font = QtGui.QFont("Times New Roman", 12)
        for button in (
            self.zoom_mode_button,
            self.psd_mode_button,
            self.back_view_button,
            self.zoom_out_button,
            self.reset_view_button,
        ):
            button.setFont(button_font)
            button.setMinimumHeight(44)
            button.setMinimumWidth(130)
        mode_row = QtWidgets.QHBoxLayout()
        mode_row.setSpacing(4)
        mode_row.addWidget(self.zoom_mode_button)
        mode_row.addWidget(self.psd_mode_button)
        mode_row.addWidget(self.back_view_button)
        mode_row.addWidget(self.zoom_out_button)
        mode_row.addWidget(self.reset_view_button)
        self.visible_length_label = QtWidgets.QLabel("Visible: 0.000 s")
        self.window_length_label = QtWidgets.QLabel("Window: 0.000 s")
        info_font = QtGui.QFont("Times New Roman", 11)
        self.visible_length_label.setFont(info_font)
        self.window_length_label.setFont(info_font)
        mode_row.addSpacing(16)
        mode_row.addWidget(self.visible_length_label)
        mode_row.addSpacing(8)
        mode_row.addWidget(self.window_length_label)
        mode_row.addStretch(1)
        self.psd_plot = pg.PlotWidget()
        configure_plot_widget(self.time_plot, "Phase (rad)", "Time")
        configure_plot_widget(self.psd_plot, "PSD (dB rad^2/Hz)", "Frequency (Hz)")
        self.psd_plot.setLogMode(x=True, y=False)
        self.time_curve = self.time_plot.plot(pen=make_pen("#CC2222", 1))
        self.time_curve.setClipToView(True)
        self.time_curve.setDownsampling(auto=True, method="peak")
        self.time_curve.setSkipFiniteCheck(True)
        self.psd_curve = self.psd_plot.plot(pen=make_pen("#AA3333", 1))
        self.psd_curve.setSkipFiniteCheck(True)
        time_layout.addWidget(self.time_plot, stretch=1)
        time_layout.addLayout(mode_row)
        right_panel.addWidget(time_panel)
        right_panel.addWidget(self.psd_plot)
        right_panel.setSizes([500, 400])

        main_layout.addWidget(control_panel)
        main_layout.addWidget(right_panel, stretch=1)

        self.statusBar().showMessage("Ready.")
        self._apply_fonts()
        self._update_interaction_mode()

    def _apply_fonts(self) -> None:
        self.setFont(QtGui.QFont("SimSun", 10))

    def _bind_events(self) -> None:
        self.browse_button.clicked.connect(self._choose_directory)
        self.refresh_button.clicked.connect(self._refresh_file_list)
        self.sort_field_combo.currentIndexChanged.connect(self._refresh_file_list)
        self.sort_order_combo.currentIndexChanged.connect(self._refresh_file_list)
        self.file_list.currentRowChanged.connect(self._handle_file_selection)
        self.home_button.clicked.connect(lambda: self._change_page(0))
        self.prev_button.clicked.connect(lambda: self._change_page(self._page_index - 1))
        self.next_button.clicked.connect(lambda: self._change_page(self._page_index + 1))
        self.end_button.clicked.connect(self._go_to_last_page)
        self.apply_filter_button.clicked.connect(self._rebuild_time_plot)
        self.apply_y_range_button.clicked.connect(self._apply_y_range)
        self.zoom_mode_button.clicked.connect(
            lambda checked: checked and self._set_interaction_mode(InteractionMode.ZOOM)
        )
        self.psd_mode_button.clicked.connect(
            lambda checked: checked and self._set_interaction_mode(InteractionMode.WINDOW_PSD)
        )
        self.back_view_button.clicked.connect(self._restore_previous_view)
        self.zoom_out_button.clicked.connect(self._zoom_out_time_plot)
        self.reset_view_button.clicked.connect(self._reset_time_plot)
        self.time_plot.windowSelected.connect(self._update_psd_from_selection)
        self.time_plot.clearSelectionRequested.connect(self._clear_selection)
        self.time_plot.getViewBox().sigRangeChanged.connect(self._record_view_history)
        self.time_plot.getViewBox().sigRangeChanged.connect(self._update_visible_length_label)

    def _choose_directory(self) -> None:
        directory = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Select Data Directory",
            self.directory_edit.text(),
        )
        if directory:
            self.directory_edit.setText(directory)
            self._page_index = 0
            self._refresh_file_list()

    def _refresh_file_list(self) -> None:
        directory = Path(self.directory_edit.text().strip())
        sort_field = self.sort_field_combo.currentData()
        ascending = bool(self.sort_order_combo.currentData())

        try:
            self._all_files = list_npz_files(directory, sort_field=sort_field, ascending=ascending)
            self.statusBar().showMessage(f"Loaded directory: {directory}")
        except Exception as exc:
            self._all_files = []
            self.file_list.clear()
            self.page_info_label.setText("Page 0 / 0 | Total 0")
            self.statusBar().showMessage(str(exc))
            return

        self._change_page(self._page_index)

    def _change_page(self, page_index: int) -> None:
        page = paginate_files(self._all_files, page_index=page_index, page_size=PAGE_SIZE)
        self._page_index = page.page_index
        self.file_list.blockSignals(True)
        self.file_list.clear()
        for record in page.items:
            list_item = QtWidgets.QListWidgetItem(record.name)
            list_item.setData(QtCore.Qt.UserRole, record.path)
            self.file_list.addItem(list_item)
        self.file_list.blockSignals(False)

        current_page = page.page_index + 1 if page.total_count else 0
        display_page_count = page.page_count if page.total_count else 0
        self.page_info_label.setText(
            f"Page {current_page} / {display_page_count} | Total {page.total_count}"
        )

        self.home_button.setEnabled(page.page_index > 0)
        self.prev_button.setEnabled(page.page_index > 0)
        self.next_button.setEnabled(page.page_index < page.page_count - 1 and page.total_count > 0)
        self.end_button.setEnabled(page.page_index < page.page_count - 1 and page.total_count > 0)

        if self.file_list.count() > 0:
            self.file_list.setCurrentRow(0)
        else:
            self._current_waveform = None
            self._current_display_values = np.array([], dtype=np.float64)
            self.time_curve.setData([])
            self.psd_curve.setData([], [])
            self.time_plot.clear_selection_region()
            self.visible_length_label.setText("Visible: 0.000 s")
            self.window_length_label.setText("Window: 0.000 s")

    def _go_to_last_page(self) -> None:
        page_count = paginate_files(self._all_files, 0, PAGE_SIZE).page_count
        self._change_page(max(0, page_count - 1))

    def _handle_file_selection(self, row: int) -> None:
        if row < 0:
            return
        item = self.file_list.item(row)
        if item is None:
            return

        path = item.data(QtCore.Qt.UserRole)
        if not path:
            return

        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            self._current_waveform = load_waveform(Path(path))
            self._rebuild_time_plot()
            warning = self._current_waveform.data_info_warning
            if warning:
                self.statusBar().showMessage(f"{self._current_waveform.path.name}: {warning}")
            else:
                self.statusBar().showMessage(f"Opened {self._current_waveform.path.name}")
        except Exception as exc:
            self._current_waveform = None
            self.statusBar().showMessage(f"Failed to open file: {exc}")
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()

    def _get_display_values(self) -> Optional[np.ndarray]:
        if self._current_waveform is None:
            return None

        values = self._current_waveform.phase_data
        enabled = self.filter_enabled_checkbox.isChecked()
        mode = self.filter_mode_combo.currentData()
        low_cut = float(self.low_cut_spin.value())
        high_cut = float(self.high_cut_spin.value())
        valid, message = validate_filter(
            enabled=enabled,
            mode=mode,
            sample_rate=self._current_waveform.sample_rate,
            low_cut_hz=low_cut,
            high_cut_hz=high_cut,
        )
        if not valid:
            self.statusBar().showMessage(message)
            return values

        return apply_display_filter(
            values=values,
            sample_rate=self._current_waveform.sample_rate,
            enabled=enabled,
            mode=mode,
            low_cut_hz=low_cut,
            high_cut_hz=high_cut,
        )

    def _rebuild_time_plot(self) -> None:
        if self._current_waveform is None:
            return

        values = self._get_display_values()
        if values is None:
            return

        self._current_display_values = values
        self.time_curve.setData(values)
        bottom_axis = self.time_plot.getPlotItem().getAxis("bottom")
        if isinstance(bottom_axis, AbsoluteTimeAxis):
            bottom_axis.set_context(
                start_time=self._current_waveform.start_time,
                sample_rate=self._current_waveform.sample_rate,
            )
        self.time_plot.set_data_context(
            data_length=len(values),
            sample_rate=self._current_waveform.sample_rate,
            min_window_seconds=0.001,
        )
        self.time_plot.clear_selection_region()
        self.psd_curve.setData([], [])
        self.window_length_label.setText("Window: 0.000 s")
        self._clear_view_history()
        self._apply_view_state(
            ((0.0, float(max(1, len(self._current_display_values) - 1))), self._default_y_range())
        )

    def _apply_y_range(self) -> None:
        if self._current_waveform is None:
            return

        y_min = float(self.y_min_spin.value())
        y_max = float(self.y_max_spin.value())
        view_box = self.time_plot.getViewBox()
        if y_min == 0.0 and y_max == 0.0:
            view_box.enableAutoRange(axis=pg.ViewBox.YAxis, enable=True)
            return
        if y_min >= y_max:
            view_box.enableAutoRange(axis=pg.ViewBox.YAxis, enable=True)
            self.statusBar().showMessage("Invalid Y range. Switched to auto range.")
            return

        view_box.enableAutoRange(axis=pg.ViewBox.YAxis, enable=False)
        view_box.setYRange(y_min, y_max, padding=0.0)

    def _set_interaction_mode(self, mode: InteractionMode) -> None:
        self.time_plot.set_interaction_mode(mode)
        self.statusBar().showMessage(f"Interaction mode: {mode.value}")

    def _update_interaction_mode(self) -> None:
        if self.zoom_mode_button.isChecked():
            self._set_interaction_mode(InteractionMode.ZOOM)
        else:
            self._set_interaction_mode(InteractionMode.WINDOW_PSD)

    def _zoom_out_time_plot(self) -> None:
        self._push_current_view_to_history()
        self.time_plot.getViewBox().scaleBy((2.0, 1.0))

    def _reset_time_plot(self) -> None:
        if self._current_waveform is None:
            return
        self._push_current_view_to_history()
        self._apply_view_state(
            ((0.0, float(max(1, len(self._current_display_values) - 1))), self._default_y_range())
        )

    def _clear_selection(self) -> None:
        self.time_plot.clear_selection_region()
        self.psd_curve.setData([], [])
        self.psd_plot.getViewBox().enableAutoRange(axis=pg.ViewBox.XAxis, enable=True)
        self._apply_psd_y_range()
        self.window_length_label.setText("Window: 0.000 s")
        self.statusBar().showMessage("Selection cleared.")

    def _update_psd_from_selection(self, start_index: int, end_index: int) -> None:
        if self._current_waveform is None:
            return

        raw_values = self._current_waveform.phase_data[start_index:end_index]
        freqs, psd_db = compute_window_psd(raw_values, self._current_waveform.sample_rate)
        valid = freqs > 0.0
        freqs = freqs[valid]
        psd_db = psd_db[valid]
        if freqs.size == 0:
            self.psd_curve.setData([], [])
            self.statusBar().showMessage("Selection window is too short for PSD.")
            return

        self.psd_curve.setData(freqs, psd_db)
        nyquist = self._current_waveform.sample_rate / 2.0
        lower_hz = max(1.0, min(1000.0, nyquist))
        self.psd_plot.setXRange(np.log10(lower_hz), np.log10(nyquist), padding=0.0)
        self._apply_psd_y_range()
        window_seconds = max(0.0, (end_index - start_index) / self._current_waveform.sample_rate)
        self.window_length_label.setText(f"Window: {window_seconds:.6f} s")
        self.statusBar().showMessage(
            f"PSD updated for samples {start_index} to {end_index}."
        )

    def _record_view_history(self, _, view_range) -> None:
        if self._suspend_history:
            return
        x_range = tuple(float(value) for value in view_range[0])
        y_range = tuple(float(value) for value in view_range[1])
        new_state = (x_range, y_range)
        if self._last_view_state is None:
            self._last_view_state = new_state
            return
        if self._states_close(new_state, self._last_view_state):
            return
        self._view_history.append(self._last_view_state)
        if len(self._view_history) > 30:
            self._view_history.pop(0)
        self._last_view_state = new_state
        self.back_view_button.setEnabled(bool(self._view_history))

    def _push_current_view_to_history(self) -> None:
        state = self._current_view_state()
        if state is None:
            return
        if self._last_view_state is None:
            self._last_view_state = state
        if self._view_history and self._states_close(self._view_history[-1], state):
            return
        if self._last_view_state and self._states_close(self._last_view_state, state):
            self._view_history.append(state)
        else:
            self._view_history.append(state)
            self._last_view_state = state
        if len(self._view_history) > 30:
            self._view_history.pop(0)
        self.back_view_button.setEnabled(bool(self._view_history))

    def _restore_previous_view(self) -> None:
        if not self._view_history:
            return
        state = self._view_history.pop()
        self._apply_view_state(state)
        self.back_view_button.setEnabled(bool(self._view_history))
        self.statusBar().showMessage("Returned to previous view.")

    def _clear_view_history(self) -> None:
        self._view_history.clear()
        self._last_view_state = None
        self.back_view_button.setEnabled(False)

    def _current_view_state(self) -> Optional[tuple[tuple[float, float], tuple[float, float]]]:
        if self._current_waveform is None:
            return None
        x_range, y_range = self.time_plot.getViewBox().viewRange()
        return (
            (float(x_range[0]), float(x_range[1])),
            (float(y_range[0]), float(y_range[1])),
        )

    def _default_y_range(self) -> tuple[float, float]:
        y_min = float(self.y_min_spin.value())
        y_max = float(self.y_max_spin.value())
        if y_min != 0.0 or y_max != 0.0:
            if y_min < y_max:
                return (y_min, y_max)

        if self._current_display_values.size == 0:
            return (-1.0, 1.0)
        data_min = float(np.min(self._current_display_values))
        data_max = float(np.max(self._current_display_values))
        if data_min == data_max:
            pad = max(1.0, abs(data_min) * 0.1)
            return (data_min - pad, data_max + pad)
        pad = max((data_max - data_min) * 0.02, 1e-9)
        return (data_min - pad, data_max + pad)

    def _apply_view_state(
        self, state: tuple[tuple[float, float], tuple[float, float]]
    ) -> None:
        self._suspend_history = True
        try:
            x_range, y_range = state
            self.time_plot.enableAutoRange(axis=pg.ViewBox.XAxis, enable=False)
            self.time_plot.getViewBox().enableAutoRange(axis=pg.ViewBox.YAxis, enable=False)
            self.time_plot.setXRange(x_range[0], x_range[1], padding=0.0)
            self.time_plot.getViewBox().setYRange(y_range[0], y_range[1], padding=0.0)
        finally:
            self._suspend_history = False
        self._last_view_state = state
        self._refresh_length_labels()

    def _update_visible_length_label(self, *_args) -> None:
        self._refresh_length_labels()

    def _refresh_length_labels(self) -> None:
        if self._current_waveform is None:
            self.visible_length_label.setText("Visible: 0.000 s")
            return
        x_range, _ = self.time_plot.getViewBox().viewRange()
        sample_rate = max(self._current_waveform.sample_rate, 1.0)
        visible_seconds = max(0.0, (float(x_range[1]) - float(x_range[0])) / sample_rate)
        self.visible_length_label.setText(f"Visible: {visible_seconds:.6f} s")

    def _apply_psd_y_range(self) -> None:
        view_box = self.psd_plot.getViewBox()
        view_box.enableAutoRange(axis=pg.ViewBox.YAxis, enable=False)
        view_box.setRange(yRange=(-120.0, -45.0), padding=0.0, disableAutoRange=True)

    @staticmethod
    def _states_close(
        left: tuple[tuple[float, float], tuple[float, float]],
        right: tuple[tuple[float, float], tuple[float, float]],
    ) -> bool:
        return all(
            abs(a - b) < 1e-6
            for pair_left, pair_right in zip(left, right)
            for a, b in zip(pair_left, pair_right)
        )
